This folder should contain:

ASD TCPServer Developers Kit Document - DevKit.doc
ASD TCPServer "C" Examples Folder
ASD TCPServer LABView Examples Folder
ASD TCPServer Developer's Guide Folder

Start by reading DevKit.doc